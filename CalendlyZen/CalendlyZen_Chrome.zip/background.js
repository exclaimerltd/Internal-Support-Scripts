chrome.runtime.onInstalled.addListener(() => {
  console.log("Clipboard Modifier extension installed");
});
