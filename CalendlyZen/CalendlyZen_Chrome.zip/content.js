document.addEventListener('mousedown', function (event) {
  if (event.button === 0) {
    navigator.clipboard.readText().then((text) => {

      const regex = /^https:\/\/calendly\.com\/(?:d\/[\w-]+\/[\w-]+|[\w-]+\/[\w-]+)$/;
      const match = text.match(regex);

      if (match) {
        const modifiedText = `${match[0]}/?name={{ticket.requester.name}}&email={{ticket.requester.email}}&a1={{ticket.id}}`;

        navigator.clipboard.writeText(modifiedText).then(() => {
          console.log("Clipboard content modified:", modifiedText);
        }).catch((err) => {
          console.error("Failed to write to clipboard:", err);
        });
      }

    }).catch((err) => {
      console.error("Failed to read clipboard contents:", err);
    });
  }
});